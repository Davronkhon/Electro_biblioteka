<!doctype html>
<html lang="en">
<head>
<title>Регистрационная форма для Софтбола <?php echo date('Y'); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Softball Registration Form Widget Responsive, Login form web template,Flat Pricing tables,Flat Drop downs  Sign up Web Templates, Flat Web Templates, Login signup Responsive web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- font files -->
<!-- /font files -->
<!-- css files -->
<link href="css/style.css" rel='stylesheet' type='text/css' media="all" />
<!-- /css files -->
<link href="css/wickedpicker.css" rel="stylesheet" type='text/css' media="all" />
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
</head>
<body>
	<div class="w3-banner-main">
		<div class="center-container">
			<h1 class="header-w3ls">Регистрационная форма для Софтбола <?php echo date('Y'); ?></h1>
			<div class="content-top">
				<div class="content-w3ls">
					<div class="form-w3ls">
						<form action="registrate.php" method="GET">
							<div class="content-wthree1">
								<div class="grid-agileits1">
									<div class="form-control"> 
										<label class="header">Имя игрока</label>
										<input type="text" id="name" name="player_name" placeholder="" title="Please enter your Full Name" required="">
									</div>
									
									<div class="form-control">	
										<label class="header">Email </label>
										<input type="email" id="email" name="email" placeholder="" title="Please enter a Valid Email Address" required="">
									</div>
									
									<div class="form-control"> 
										<label class="header">Имя родителя</label>
										<input type="text" id="name" name="parent_name" placeholder="" title="Please enter your Full Name" required="">
									</div>
									<div class="grid-w3layouts1">
									<div class="w3-agile1">
										<label class="rating">Выбрать пол</label>
										<ul>
											<li>
												<input type="radio" id="a-option" value="Мужской" name="gender">
												<label for="a-option">М</label>
												<div class="check"></div>
											</li>
											<li>
												<input type="radio" id="b-option" value="Женский" name="gender">
												<label for="b-option">Ж</label>
												<div class="check"><div class="inside"></div></div>
											</li>
											
										</ul>
									</div>
								</div>
								<div class="form-control">
							<label class="header">Дата присоединения</label>	
							<input  id="datepicker1" name="date_of_joining" type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'mm/dd/yyyy';}" required="">
						</div>
						<div class="gaps">
							<label class="header">Время</label>	
							<input type="text" id="timepicker" name="Time" class="timepicker form-control" value="">	
						</div>	
								</div>
							</div>
					</div>
					<div class="form-w3ls-1">
						<div class="form-control">	
							<label class="header">Телефон</label>
							<input type="text" id="name" name="phone_number" placeholder="" title="Please enter your Phone Number" required="">
						</div>					
						<div class="form-control"> 
							<label class="header">Адрес</label>
							<input type="text" id="name" name="address" placeholder="" title="Please enter your Full Name" required="">
						</div>	
						<div class="form-control"> 
							<label class="header">Почтовый индекс</label>
							<input type="text" id="name" name="zip_code" placeholder="" title="Please enter your Full Name" required="">
						</div>
						<div class="form-control">
								<label class="header">Город</label>		
									<select class="form-control" name="city">
										<option></option>
										<option value="Худжанд">Худжанд</option>
										<option value="Гафуров">Гафуров</option>
										<option value="Ашт">Ашт</option>
										<option value="Рашт">Рашт</option>
										<option value="Душанбе">Душанбе</option>
									</select>
						</div>
							<div class="form-control Insurance"> 
									<label class="header">Хотел бы потграть</label>
									<textarea  name="like_play" placeholder="" title="" required=""></textarea>
							</div>
									  <input type="submit" value="Регистрация" name="save">
									  </form>
					</div>				
					<div class="clear"></div>
				</div>
			</div>	
				
				<p class="copyright">© <?php echo date('Y'); ?> Softball Registration Form. All Rights Reserved | Design by <a href="#" target="_blank">W3layouts</a></p>
		</div>
	</div>

<!-- Calendar -->
				<link rel="stylesheet" href="css/jquery-ui.css" />
				<script src="js/jquery-ui.js"></script>
				  <script>
						  $(function() {
							$( "#datepicker,#datepicker1,#datepicker2,#datepicker3" ).datepicker();
						  });
				  </script>
			<!-- //Calendar -->
			<script type="text/javascript" src="js/wickedpicker.js"></script>
			<script type="text/javascript">
				$('.timepicker').wickedpicker({twentyFour: false});
			</script>


</body>
</html>
