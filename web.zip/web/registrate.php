<?php
if(isset($_GET['save']))
{
    require_once('connection.php');
    $player_name = "";
    $email = "";
    $parent_name = "";
    $gender = "";
    $date_of_joining = "";
    $time = "";
    $phone_number = "";
    $address = "";
    $zip_code = "";
    $city = "";
    $like_play = "";

    if(isset($_GET['player_name']) && !empty($_GET['player_name'])) $player_name = $_GET['player_name'];
    if(isset($_GET['email']) && !empty($_GET['email'])) $email = $_GET['email'];
    if(isset($_GET['parent_name']) && !empty($_GET['parent_name'])) $parent_name = $_GET['parent_name'];
    if(isset($_GET['gender']) && !empty($_GET['gender'])) $gender = $_GET['gender'];
    if(isset($_GET['date_of_joining']) && !empty($_GET['date_of_joining'])) $date_of_joining = $_GET['date_of_joining'];
    if(isset($_GET['time']) && !empty($_GET['time'])) $time = $_GET['time'];
    if(isset($_GET['phone_number']) && !empty($_GET['phone_number'])) $phone_number = $_GET['phone_number'];
    if(isset($_GET['address']) && !empty($_GET['address'])) $address = $_GET['address'];
    if(isset($_GET['zip_code']) && !empty($_GET['zip_code'])) $zip_code = $_GET['zip_code'];
    if(isset($_GET['city']) && !empty($_GET['city'])) $city = $_GET['city'];
    if(isset($_GET['like_play']) && !empty($_GET['like_play'])) $like_play = $_GET['like_play'];

    echo $player_name."<br>";
    echo $email."<br>";
    echo $parent_name."<br>";
    echo $gender."<br>";
    echo $date_of_joining."<br>";
    echo $time."<br>";
    echo $phone_number."<br>";
    echo $address."<br>";
    echo $zip_code."<br>";
    echo $city."<br>";
    echo $like_play."<br>";

    $query = " INSERT INTO `softball`.`softball` (player_name,email,parent_name,gender,date_of_joining,`time`,phone_number,`address`,zip_code,city,like_play)
    VALUES ('$player_name','$email','$parent_name','$gender','$date_of_joining','$time','$phone_number','$address','$zip_code','$city','$like_play');";

    echo $query;
    mysqli_query($conn,$query);
    ?>
    <script>
        alert("Успешно добавлен !");
    </script>
    <?php
}
?>